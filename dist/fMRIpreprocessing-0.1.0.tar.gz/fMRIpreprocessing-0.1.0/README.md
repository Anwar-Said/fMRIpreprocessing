# fMRIpreprocessing
This repository provides a package for preprocessing fMRI data
